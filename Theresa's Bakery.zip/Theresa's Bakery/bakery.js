function check_empty() {
if (document.getElementById('name').value == "" || document.getElementById('email').value == "" || document.getElementById('msg').value == "") {
alert("You Need To Fill All Fields !");
} else {
document.getElementById('form').submit();
alert("Your Form Was Submitted Successfully...");
}
}
function div_show() {
document.getElementById('theresa').style.display = "block";
}
function div_hide(){
document.getElementById('theresa').style.display = "none";
}

/*Additional Javascript code is in the HTMl files.
Please check the script tags in the HTML files. */
/*links to about.html*/
	var text1 = "As founder of the now famous international bakery, Theresa Vu started from simple beginnings.";
	var text2 = "She baked bread for the first time at age 17 and never looked back.";
	var text3 = "Of all the wheat varieteies out there, she worked hard to master einkorn wheat after years of trial and error.";
	var text4 = "Now, after several years of sweat and tears, Theresa is proud to present Theresa's Bakery located in various regions throughout the world.";
	var text5 = "Each bakery upholds the highest standards of ingredients and equipment no matter what.";
	var text6 = "So be sure to try all our menus when you get the chance!";

	document.getElementById("adding").innerHTML = text1 + " " + text2 + " " + text3 + " " + text4 + " " + text5 + " " + text6;

/*links to menu.html*/
$(document).ready(function(){
    $("button").click(function(){
        $(".everything").toggle();
    });

/*links to faq.html*/
$(document).ready(function(){
    	$(".b1").click(function(){
        $(".q1").text("All products are baked using einkorn flour.");
    	});
	});

	$(document).ready(function(){
    	$(".b2").click(function(){
        $(".q2").text("That will be specified and listed on each product that you order at any Theresa's Bakery location.");
    	});
	});

	$(document).ready(function(){
    	$(".b3").click(function(){
        $(".q3").text("No.");
    	});
	});


/*Contact Button*/
function check_empty() {
if (document.getElementById('name').value == "" || document.getElementById('email').value == "" || document.getElementById('msg').value == "") {
alert("You Need To Fill All Fields !");
} else {
document.getElementById('form').submit();
alert("Your Form Was Submitted Successfully...");
}
}
function div_show() {
document.getElementById('theresa').style.display = "block";
}
function div_hide(){
document.getElementById('theresa').style.display = "none";
}

/*Additional Javascript code is in the HTMl files.
Please check the script tags in the HTML files. */